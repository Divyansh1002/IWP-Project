import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# 1. Load PPI with gene names
ppi = pd.read_csv("ppi_human_min700_onlyAB_with_genes.tsv", sep="\t")

# 2. Use the same extended Alzheimer gene list
alz_genes = [
    "APP", "PSEN1", "PSEN2", "APOE", "TOMM40", "MAPT", "BACE1", "BACE2",
    "ADAM10", "NCSTN", "PSENEN", "SORL1", "APBB1",
    "CLU", "CR1", "PICALM", "ABCA7", "MS4A6A", "MS4A4E", "CD33", "CD2AP",
    "BIN1", "FERMT2", "CASS4", "EPHA1", "PTK2B", "SLC24A4", "MEF2C", "NME8",
    "INPP5D", "PLCG2", "ABI3", "SPI1", "TREM2", "TREM1", "TYROBP",
    "C4A", "C4B", "HLA-DRB1", "HLA-DRB5", "HLA-DQA1", "HLA-DQB1",
    "IL6", "IL1B", "IL10", "TNF", "CX3CR1", "CCR5", "TLR4",
    "LDLR", "A2M", "ACE", "APOC1", "NR1H3",
    "GRIN1", "GRIN2A", "GRIN2B", "CAMK2A", "VGF",
    "NDUFA9", "NDUFS3", "UQCRC1", "COX4I1", "ATP5F1A",
    "PRNP", "SNCA", "SOD1",
    "GSK3B", "TGFB1", "STAT3", "EGFR",
    "IDE", "NGF", "CTSD"
]
alz_set = set(alz_genes)

# 3. Filter PPI to edges where at least one end is an Alzheimer gene
sub_ppi = ppi[(ppi["gene1"].isin(alz_set)) | (ppi["gene2"].isin(alz_set))].copy()
print("Edges in Alzheimer subnetwork:", len(sub_ppi))

# 4. Build graph
G = nx.Graph()

for _, row in sub_ppi.iterrows():
    g1 = row["gene1"]
    g2 = row["gene2"]
    score = row["combined_score"]
    if pd.isna(g1) or pd.isna(g2):
        continue
    G.add_edge(g1, g2, weight=score)

print("Nodes in Alzheimer graph:", G.number_of_nodes())

# Optional: keep only largest connected component to avoid tiny isolated nodes
if G.number_of_nodes() > 0:
    largest_cc = max(nx.connected_components(G), key=len)
    G_sub = G.subgraph(largest_cc).copy()
else:
    G_sub = G

print("Nodes in largest component:", G_sub.number_of_nodes())
print("Edges in largest component:", G_sub.number_of_edges())

# 5. Draw graph
plt.figure(figsize=(12, 10))

# Positions with spring layout (force-directed)
pos = nx.spring_layout(G_sub, k=0.3, iterations=50)

# Node size scaled by degree
degrees = dict(G_sub.degree())
node_sizes = [50 + 20 * degrees[n] for n in G_sub.nodes()]

# Edge width scaled by STRING score
edge_weights = [G_sub[u][v]["weight"] for u, v in G_sub.edges()]
edge_widths = [w / 200.0 for w in edge_weights]  # scale scores ~ [0,5]

nx.draw_networkx_edges(G_sub, pos, width=edge_widths, alpha=0.4)
nx.draw_networkx_nodes(G_sub, pos, node_size=node_sizes)
nx.draw_networkx_labels(G_sub, pos, font_size=8)

plt.title("Alzheimer's Disease PPI Subnetwork (STRING v12, score ≥ 700)")
plt.axis("off")
plt.tight_layout()
plt.savefig("alzheimers_ppi_graph.png", dpi=300)
plt.show()
