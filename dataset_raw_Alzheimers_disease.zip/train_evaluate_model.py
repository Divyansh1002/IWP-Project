import pandas as pd
from math import sqrt

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    mean_squared_error,
    roc_curve,
    auc,
    precision_recall_curve
)

import shap
import matplotlib.pyplot as plt
import numpy as np

# -----------------------------------------------------------
# 1. Load datasets
# -----------------------------------------------------------

train = pd.read_csv("train_Alzheimers_disease.csv")
val   = pd.read_csv("val_Alzheimers_disease.csv")
test  = pd.read_csv("test_Alzheimers_disease.csv")

# -----------------------------------------------------------
# 2. Pick features dynamically (use what exists)
# -----------------------------------------------------------

candidate_features = ["protein_code", "degree_centrality", "betweenness_centrality"]
features = [f for f in candidate_features if f in train.columns]

if not features:
    raise ValueError(
        "No usable features found. Expected at least one of: "
        f"{candidate_features}. Check your CSV columns."
    )

print("Using features:", features)

TARGET = "label"

X_train = train[features]
y_train = train[TARGET]

X_val = val[features]
y_val = val[TARGET]

X_test = test[features]
y_test = test[TARGET]

# -----------------------------------------------------------
# 3. Train Random Forest
# -----------------------------------------------------------

model = RandomForestClassifier(
    n_estimators=300,
    max_depth=10,
    random_state=42
)

model.fit(X_train, y_train)

# -----------------------------------------------------------
# 4. Evaluate on validation set
# -----------------------------------------------------------

val_pred = model.predict(X_val)
val_prob = model.predict_proba(X_val)[:, 1]

val_accuracy = accuracy_score(y_val, val_pred)
val_precision = precision_score(y_val, val_pred)
val_recall = recall_score(y_val, val_pred)
val_f1 = f1_score(y_val, val_pred)
val_rmse = sqrt(mean_squared_error(y_val, val_prob))

print("\n===== VALIDATION RESULTS =====")
print("Accuracy :", val_accuracy)
print("Precision:", val_precision)
print("Recall   :", val_recall)
print("F1-score :", val_f1)
print("RMSE     :", val_rmse)

# -----------------------------------------------------------
# 5. Evaluate on test set
# -----------------------------------------------------------

test_pred = model.predict(X_test)
test_prob = model.predict_proba(X_test)[:, 1]

test_accuracy = accuracy_score(y_test, test_pred)
test_precision = precision_score(y_test, test_pred)
test_recall = recall_score(y_test, test_pred)
test_f1 = f1_score(y_test, test_pred)
test_rmse = sqrt(mean_squared_error(y_test, test_prob))

conf_mat = confusion_matrix(y_test, test_pred)

print("\n===== TEST RESULTS =====")
print("Accuracy :", test_accuracy)
print("Precision:", test_precision)
print("Recall   :", test_recall)
print("F1-score :", test_f1)
print("RMSE     :", test_rmse)

print("\nConfusion Matrix:")
print(conf_mat)

# -----------------------------------------------------------
# 6. Feature importance plot
# -----------------------------------------------------------

importances = model.feature_importances_
indices = np.argsort(importances)[::-1]
sorted_features = [features[i] for i in indices]
sorted_importances = importances[indices]

plt.figure(figsize=(8, 6))
plt.bar(range(len(sorted_features)), sorted_importances)
plt.xticks(range(len(sorted_features)), sorted_features, rotation=45, ha="right")
plt.ylabel("Importance")
plt.title("Random Forest Feature Importances")
plt.tight_layout()
plt.savefig("feature_importances.png", dpi=300)
plt.close()
print("\nSaved feature importance plot -> feature_importances.png")

# -----------------------------------------------------------
# 7. ROC curve (on test set)
# -----------------------------------------------------------

fpr, tpr, _ = roc_curve(y_test, test_prob)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(6, 6))
plt.plot(fpr, tpr, label=f"ROC curve (AUC = {roc_auc:.3f})")
plt.plot([0, 1], [0, 1], linestyle="--", label="Random baseline")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve (Test Set)")
plt.legend()
plt.tight_layout()
plt.savefig("roc_curve.png", dpi=300)
plt.close()
print("Saved ROC curve -> roc_curve.png")

# -----------------------------------------------------------
# 8. Precision–Recall (PR) curve (on test set)
# -----------------------------------------------------------

precision, recall, _ = precision_recall_curve(y_test, test_prob)
pr_auc = auc(recall, precision)

plt.figure(figsize=(6, 6))
plt.plot(recall, precision, label=f"PR curve (AUC = {pr_auc:.3f})")
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Precision–Recall Curve (Test Set)")
plt.legend()
plt.tight_layout()
plt.savefig("pr_curve.png", dpi=300)
plt.close()
print("Saved PR curve -> pr_curve.png")

# -----------------------------------------------------------
# 9. SHAP summary plot (feature impact)
# -----------------------------------------------------------

print("\nComputing SHAP values (this may take a bit)...")

explainer = shap.TreeExplainer(model)

sample_size = min(500, len(X_train))
X_train_sample = X_train.sample(n=sample_size, random_state=42)

shap_values = explainer.shap_values(X_train_sample)

# shap_values is list [class0, class1] for binary RF; use class 1 (Alzheimer)
if isinstance(shap_values, list):
    shap_vals_class1 = shap_values[1]
else:
    shap_vals_class1 = shap_values

if len(features) == 1:
    # Only 1 feature: SHAP summary beeswarm is overkill & buggy.
    # Just save a simple bar plot of mean |SHAP| for that feature.
    mean_abs_shap = float(np.mean(np.abs(shap_vals_class1)))
    print(f"Mean |SHAP| for feature '{features[0]}': {mean_abs_shap:.6f}")

    plt.figure(figsize=(4, 4))
    plt.bar([features[0]], [mean_abs_shap])
    plt.ylabel("Mean |SHAP value|")
    plt.title("SHAP impact for single feature")
    plt.tight_layout()
    plt.savefig("shap_summary_single_feature.png", dpi=300)
    plt.close()
    print("Saved SHAP plot for single feature -> shap_summary_single_feature.png")

else:
    # Multiple features -> use proper SHAP summary plot
    plt.figure()
    shap.summary_plot(
        shap_vals_class1,
        X_train_sample,
        show=False
    )
    plt.tight_layout()
    plt.savefig("shap_summary.png", dpi=300)
    plt.close()
    print("Saved SHAP summary plot -> shap_summary.png")

print("\nAll done. Generated files:")
print(" - feature_importances.png")
print(" - roc_curve.png")
print(" - pr_curve.png")
print(" - shap_summary.png")
