#!/usr/bin/env python3
"""
Prepare dataset for Alzheimer's disease target prediction using STRING v12.0.

Inputs (in same folder):
  - 9606.protein.links.v12.0.min700.onlyAB.txt
  - 9606.protein.info.v12.0.txt

Outputs:
  - ppi_human_min700_onlyAB_with_genes.tsv
  - dataset_raw_Alzheimers_disease.csv
  - train_Alzheimers_disease.csv
  - val_Alzheimers_disease.csv
  - test_Alzheimers_disease.csv
"""

import os
import pandas as pd
from sklearn.model_selection import train_test_split

# ========= CONFIG =========
PPI_PATH  = "9606.protein.links.v12.0.min700.onlyAB.txt"
INFO_PATH = "9606.protein.info.v12.0.txt"

DISEASE_NAME = "Alzheimer's disease"  # used in filenames
# ==========================


def load_string_data():
    """Load STRING PPI network and protein info."""
    print("[1] Loading STRING PPI links from:", PPI_PATH)
    # space-separated; works for .txt or .txt.gz
    ppi = pd.read_csv(PPI_PATH, sep=r"\s+", compression="infer")
    print("    PPI shape:", ppi.shape)
    print("    PPI columns:", list(ppi.columns))

    print("[2] Loading STRING protein info from:", INFO_PATH)
    info = pd.read_csv(INFO_PATH, sep="\t", compression="infer")
    print("    Info shape:", info.shape)
    print("    Info columns:", list(info.columns))

    # STRING v12 uses '#string_protein_id' instead of 'protein_external_id'
    if "#string_protein_id" not in info.columns or "preferred_name" not in info.columns:
        raise ValueError(
            "Expected columns '#string_protein_id' and 'preferred_name' "
            "not found in protein info file."
        )

    # Keep only mapping we need and rename
    info = info[["#string_protein_id", "preferred_name"]].copy()
    info.columns = ["protein_id", "gene_symbol"]

    return ppi, info



def add_gene_names_to_ppi(ppi, info):
    """
    Attach gene symbols to protein1/protein2 in the PPI table.
    This is useful for any downstream analysis or visualization.
    """
    print("[3] Adding gene names to PPI (this may take a bit)...")

    # protein1 → gene1
    ppi = ppi.merge(info, left_on="protein1", right_on="protein_id", how="left")
    ppi = ppi.rename(columns={"gene_symbol": "gene1"}).drop(columns=["protein_id"])

    # protein2 → gene2
    ppi = ppi.merge(info, left_on="protein2", right_on="protein_id", how="left")
    ppi = ppi.rename(columns={"gene_symbol": "gene2"}).drop(columns=["protein_id"])

    print("    PPI with genes shape:", ppi.shape)
    return ppi


def build_labeled_dataset(info):
    """
    Build a labeled dataset using a curated Alzheimer's disease gene list
    (no DisGeNET required).

    Positives: proteins whose gene_symbol is in alz_genes.
    Negatives: random proteins whose gene_symbol is NOT in alz_genes.
    """

    # <<< Curated Alzheimer's disease gene list (80 genes) >>>
    alz_genes = [
    # Core amyloid / tau / lipid genes
    "APP", "PSEN1", "PSEN2", "APOE", "TOMM40", "MAPT", "BACE1", "BACE2",
    "ADAM10", "NCSTN", "PSENEN", "SORL1", "APBB1",

    # Established GWAS loci
    "CLU", "CR1", "PICALM", "ABCA7", "MS4A6A", "MS4A4E", "CD33", "CD2AP",
    "BIN1", "FERMT2", "CASS4", "EPHA1", "PTK2B", "SLC24A4", "MEF2C", "NME8",
    "INPP5D", "PLCG2", "ABI3", "SPI1", "TREM2", "TREM1", "TYROBP",

    # Immune / complement / HLA
    "C4A", "C4B", "HLA-DRB1", "HLA-DRB5", "HLA-DQA1", "HLA-DQB1",
    "IL6", "IL1B", "IL10", "TNF", "CX3CR1", "CCR5", "TLR4",

    # Cholesterol / lipid metabolism & transport
    "LDLR", "A2M", "ACE", "APOC1", "NR1H3",

    # Synaptic / glutamatergic / Ca2+ related
    "GRIN1", "GRIN2A", "GRIN2B", "CAMK2A", "VGF",

    # Oxidative phosphorylation / mitochondria (subset)
    "NDUFA9", "NDUFS3", "UQCRC1", "COX4I1", "ATP5F1A",

    # Misfolded protein / prion / Parkinson overlap
    "PRNP", "SNCA", "SOD1",

    # Signalling / kinases / transcription
    "GSK3B", "TGFB1", "STAT3", "EGFR",

    # Other pathway / stress-related
    "IDE", "NGF", "CTSD"
    ]


    print("[4] Building labeled dataset for Alzheimer's disease")
    print("    # of curated AD genes in list:", len(alz_genes))

    # Positive samples: proteins whose gene_symbol is in AD list
    pos = info[info["gene_symbol"].isin(alz_genes)].copy()
    pos = pos.drop_duplicates(subset=["protein_id"])
    pos["label"] = 1

    print("    Positive proteins found in STRING:", len(pos))

    if len(pos) == 0:
        raise ValueError(
            "No positive proteins found for the provided Alzheimer’s gene list. "
            "Check that gene symbols match STRING 'preferred_name' values."
        )

    # All proteins (universe)
    all_proteins = info.drop_duplicates(subset=["protein_id"])

    # Candidate negatives: genes NOT in Alzheimer’s list
    neg_candidates = all_proteins[~all_proteins["gene_symbol"].isin(alz_genes)].copy()

    # Sample as many negatives as positives (balanced dataset)
    if len(neg_candidates) < len(pos):
        raise ValueError(
            "Not enough negative candidates to match positives. "
            "This should not happen with STRING; check data."
        )

    # How many negatives per positive? (change this if you want)
    NEG_MULTIPLIER = 100   # 20x more negatives than positives

    # Check we have enough candidates
    needed_neg = len(pos) * NEG_MULTIPLIER
    if len(neg_candidates) < needed_neg:
        raise ValueError(
            f"Not enough negative candidates ({len(neg_candidates)}) "
            f"to sample {needed_neg} negatives."
        )

    # Sample many more negatives (larger dataset)
    neg = neg_candidates.sample(n=needed_neg, random_state=42, replace=False)
    neg["label"] = 0

    print("    Negative proteins sampled:", len(neg))


    print("    Negative proteins sampled:", len(neg))

    # Add simple disease metadata columns for clarity
    pos["diseaseName"] = DISEASE_NAME
    neg["diseaseName"] = DISEASE_NAME

    dataset = pd.concat([pos, neg], ignore_index=True)
    print("    Total samples (pos + neg):", len(dataset))

    # Encode proteins numerically as a simple feature
    dataset["protein_code"] = dataset["protein_id"].astype("category").cat.codes

    # Reorder columns nicely
    cols_order = ["protein_id", "gene_symbol", "protein_code", "label", "diseaseName"]
    other_cols = [c for c in dataset.columns if c not in cols_order]
    dataset = dataset[cols_order + other_cols]

    return dataset


def split_and_save(dataset):
    """Create 80/10/10 train/val/test splits and save to CSVs."""
    print("[5] Creating 80/10/10 train/val/test splits...")

    X = dataset[["protein_code"]]
    y = dataset["label"]

    # 80% train, 20% temp
    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=42
    )

    # 10% val, 10% test (split temp half-half)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, stratify=y_temp, random_state=42
    )

    print("    Train:", X_train.shape, "| Val:", X_val.shape, "| Test:", X_test.shape)

    # Attach labels back
    train = X_train.copy(); train["label"] = y_train.values
    val   = X_val.copy();   val["label"] = y_val.values
    test  = X_test.copy();  test["label"] = y_test.values

    # Nice slug for filenames
    disease_slug = DISEASE_NAME.replace(" ", "_").replace("'", "").replace("/", "_")

    train_file = f"train_{disease_slug}.csv"
    val_file   = f"val_{disease_slug}.csv"
    test_file  = f"test_{disease_slug}.csv"

    train.to_csv(train_file, index=False)
    val.to_csv(val_file, index=False)
    test.to_csv(test_file, index=False)

    print("[6] Saved split datasets:")
    print(f"    {train_file}")
    print(f"    {val_file}")
    print(f"    {test_file}")


def main():
    # Load STRING data
    ppi, info = load_string_data()

    # Add gene names to PPI and save (for completeness / analysis)
    ppi_with_genes = add_gene_names_to_ppi(ppi, info)
    ppi_out = "ppi_human_min700_onlyAB_with_genes.tsv"
    ppi_with_genes.to_csv(ppi_out, sep="\t", index=False)
    print(f"[*] Saved PPI with gene names to: {ppi_out}")

    # Build labeled dataset for Alzheimer's disease
    dataset = build_labeled_dataset(info)
    raw_dataset_file = "dataset_raw_Alzheimers_disease.csv"
    dataset.to_csv(raw_dataset_file, index=False)
    print(f"[*] Saved raw labeled dataset to: {raw_dataset_file}")

    # Split into train/val/test and save
    split_and_save(dataset)

    print("\nDone. You can now use the train/val/test CSVs for your ML model.")


if __name__ == "__main__":
    main()
