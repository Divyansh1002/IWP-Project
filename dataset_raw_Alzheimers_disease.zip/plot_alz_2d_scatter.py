import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# -----------------------------------------------------------
# 1. Alzheimer’s gene list (same as in prepare_data.py)
# -----------------------------------------------------------

alz_genes = [
    # Core amyloid / tau pathway genes
    "APP", "PSEN1", "PSEN2", "APOE", "TOMM40", "MAPT", "BACE1", "BACE2",
    "ADAM10", "NCSTN", "PSENEN", "SORL1", "APBB1",

    # GWAS-established risk genes
    "CLU", "CR1", "PICALM", "ABCA7", "MS4A6A", "MS4A4E", "CD33", "CD2AP",
    "BIN1", "FERMT2", "CASS4", "EPHA1", "PTK2B", "SLC24A4", "MEF2C",
    "NME8", "INPP5D", "PLCG2", "ABI3", "SPI1", "TREM2", "TREM1", "TYROBP",

    # Immune / complement / HLA
    "C4A", "C4B", "HLA-DRB1", "HLA-DRB5", "HLA-DQA1", "HLA-DQB1",
    "IL6", "IL1B", "IL10", "TNF", "CX3CR1", "CCR5", "TLR4",

    # Lipid metabolism & transport
    "LDLR", "A2M", "ACE", "APOC1", "NR1H3",

    # Synaptic / neuronal signaling
    "GRIN1", "GRIN2A", "GRIN2B", "CAMK2A", "VGF",

    # Mitochondrial oxidative phosphorylation
    "NDUFA9", "NDUFS3", "UQCRC1", "COX4I1", "ATP5F1A",

    # Misfolded protein / prion / oxidative stress
    "PRNP", "SNCA", "SOD1",

    # Signaling
    "GSK3B", "TGFB1", "STAT3", "EGFR",

    # Other
    "IDE", "NGF", "CTSD"
]
alz_set = set(alz_genes)

# -----------------------------------------------------------
# 2. Load PPI with gene names
# -----------------------------------------------------------

ppi = pd.read_csv("ppi_human_min700_onlyAB_with_genes.tsv", sep="\t")

# edges where at least one endpoint is an AD gene
sub_ppi = ppi[(ppi["gene1"].isin(alz_set)) | (ppi["gene2"].isin(alz_set))].copy()
print("Edges in Alzheimer subnetwork:", len(sub_ppi))

# -----------------------------------------------------------
# 3. Build graph and keep largest component
# -----------------------------------------------------------

G = nx.Graph()
for _, row in sub_ppi.iterrows():
    g1, g2 = row["gene1"], row["gene2"]
    if pd.isna(g1) or pd.isna(g2):
        continue
    G.add_edge(g1, g2, weight=row["combined_score"])

print("Nodes in Alzheimer graph:", G.number_of_nodes())

if G.number_of_nodes() > 0:
    largest_cc = max(nx.connected_components(G), key=len)
    G_sub = G.subgraph(largest_cc).copy()
else:
    G_sub = G

print("Nodes in largest component:", G_sub.number_of_nodes())
print("Edges in largest component:", G_sub.number_of_edges())

# -----------------------------------------------------------
# 4. Compute centralities (numeric features)
# -----------------------------------------------------------

print("Computing centralities...")
deg_cent = nx.degree_centrality(G_sub)
btw_cent = nx.betweenness_centrality(G_sub, k=min(200, G_sub.number_of_nodes()), seed=42)

df_cent = pd.DataFrame({
    "gene": list(deg_cent.keys()),
    "degree_centrality": [deg_cent[g] for g in deg_cent.keys()],
    "betweenness_centrality": [btw_cent[g] for g in deg_cent.keys()]
})

# sort by degree to get hubs
df_cent_sorted = df_cent.sort_values("degree_centrality", ascending=False)
df_cent_sorted.to_csv("alz_centrality_all_nodes.csv", index=False)

# top 10 hubs
top10 = df_cent_sorted.head(10)["gene"].tolist()
print("\nTop 10 hub genes:")
print(df_cent_sorted.head(10))

# -----------------------------------------------------------
# 5. 2D scatter plot (degree vs betweenness)
# -----------------------------------------------------------

plt.figure(figsize=(10, 8))

# all nodes in light color
plt.scatter(
    df_cent["degree_centrality"],
    df_cent["betweenness_centrality"],
    s=20,
    alpha=0.4,
    label="All nodes"
)

# highlight top hubs in a different color and larger size
top_df = df_cent[df_cent["gene"].isin(top10)]
plt.scatter(
    top_df["degree_centrality"],
    top_df["betweenness_centrality"],
    s=80,
    alpha=0.9,
    label="Top 10 hubs"
)

# add labels for top hubs
for _, row in top_df.iterrows():
    plt.text(
        row["degree_centrality"],
        row["betweenness_centrality"],
        row["gene"],
        fontsize=9,
        ha="center",
        va="bottom"
    )

plt.xlabel("Degree centrality")
plt.ylabel("Betweenness centrality")
plt.title("Alzheimer's Disease PPI: 2D Centrality Plot")
plt.legend()
plt.tight_layout()
plt.savefig("alz_centrality_2d_scatter.png", dpi=300)
plt.show()

print("\nSaved:")
print(" - alz_centrality_all_nodes.csv")
print(" - alz_centrality_2d_scatter.png")
